package com.rotationcontrol.app

import android.content.Context
import android.provider.Settings
import android.view.Surface

enum class RotationMode { AUTO, ROT_90, ROT_0 }

object RotationController {

    fun canWrite(context: Context): Boolean = Settings.System.canWrite(context)

    /** Trả về chế độ hiện tại, hoặc null nếu đang ở hướng khác (180°/270°). */
    fun current(context: Context): RotationMode? {
        val cr = context.contentResolver
        val auto = Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0)
        if (auto == 1) return RotationMode.AUTO
        return when (Settings.System.getInt(cr, Settings.System.USER_ROTATION, Surface.ROTATION_0)) {
            Surface.ROTATION_0 -> RotationMode.ROT_0
            Surface.ROTATION_90 -> RotationMode.ROT_90
            else -> null
        }
    }

    fun apply(context: Context, mode: RotationMode): Boolean {
        if (!canWrite(context)) return false
        val cr = context.contentResolver
        return try {
            when (mode) {
                RotationMode.AUTO -> {
                    Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1)
                }
                RotationMode.ROT_90 -> {
                    Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0)
                    // ROTATION_90 = xoay ngược chiều kim đồng hồ 90°
                    Settings.System.putInt(cr, Settings.System.USER_ROTATION, Surface.ROTATION_90)
                }
                RotationMode.ROT_0 -> {
                    Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0)
                    Settings.System.putInt(cr, Settings.System.USER_ROTATION, Surface.ROTATION_0)
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
