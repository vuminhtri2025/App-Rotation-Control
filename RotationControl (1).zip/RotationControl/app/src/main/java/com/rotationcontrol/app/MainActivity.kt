package com.rotationcontrol.app

import android.app.Activity
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var cardAuto: View
    private lateinit var card90: View
    private lateinit var card0: View
    private lateinit var permissionBanner: View

    private val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cardAuto = findViewById(R.id.card_auto)
        card90 = findViewById(R.id.card_90)
        card0 = findViewById(R.id.card_0)
        permissionBanner = findViewById(R.id.permission_banner)

        cardAuto.setOnClickListener { select(RotationMode.AUTO) }
        card90.setOnClickListener { select(RotationMode.ROT_90) }
        card0.setOnClickListener { select(RotationMode.ROT_0) }
        findViewById<View>(R.id.btn_grant).setOnClickListener { openWriteSettings() }
    }

    override fun onResume() {
        super.onResume()
        contentResolver.registerContentObserver(
            Settings.System.CONTENT_URI, true, observer
        )
        refresh()
    }

    override fun onPause() {
        super.onPause()
        contentResolver.unregisterContentObserver(observer)
    }

    private fun select(mode: RotationMode) {
        if (!RotationController.canWrite(this)) {
            Toast.makeText(this, R.string.need_permission, Toast.LENGTH_SHORT).show()
            openWriteSettings()
            return
        }
        RotationController.apply(this, mode)
        refresh()
    }

    private fun openWriteSettings() {
        val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
        }
        startActivity(intent)
    }

    private fun refresh() {
        val canWrite = RotationController.canWrite(this)
        permissionBanner.visibility = if (canWrite) View.GONE else View.VISIBLE

        val current = RotationController.current(this)
        cardAuto.isSelected = current == RotationMode.AUTO
        card90.isSelected = current == RotationMode.ROT_90
        card0.isSelected = current == RotationMode.ROT_0

        RotationWidgetProvider.updateAll(this)
    }
}
