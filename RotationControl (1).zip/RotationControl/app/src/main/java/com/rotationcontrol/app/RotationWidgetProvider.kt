package com.rotationcontrol.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

class RotationWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, buildViews(context))
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_SET_MODE) {
            val name = intent.getStringExtra(EXTRA_MODE) ?: return
            val mode = runCatching { RotationMode.valueOf(name) }.getOrNull() ?: return
            RotationController.apply(context, mode)
            updateAll(context)
        }
    }

    companion object {
        const val ACTION_SET_MODE = "com.rotationcontrol.app.ACTION_SET_MODE"
        const val EXTRA_MODE = "mode"

        private val COLOR_ACTIVE_TEXT = Color.parseColor("#FFFFFF")
        private val COLOR_INACTIVE_TEXT = Color.parseColor("#D1D1D6")
        private val COLOR_ACTIVE_SUB = Color.parseColor("#E5E5EA")
        private val COLOR_INACTIVE_SUB = Color.parseColor("#8E8E93")

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, RotationWidgetProvider::class.java))
            if (ids.isEmpty()) return
            val views = buildViews(context)
            for (id in ids) manager.updateAppWidget(id, views)
        }

        private fun buildViews(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_rotation)
            val canWrite = RotationController.canWrite(context)
            val current = RotationController.current(context)

            bind(context, views, canWrite, current, RotationMode.AUTO, 0,
                R.id.btn_auto, R.id.txt_auto, R.id.sub_auto)
            bind(context, views, canWrite, current, RotationMode.ROT_90, 1,
                R.id.btn_90, R.id.txt_90, R.id.sub_90)
            bind(context, views, canWrite, current, RotationMode.ROT_0, 2,
                R.id.btn_0, R.id.txt_0, R.id.sub_0)

            // Bấm tiêu đề để mở app
            val open = PendingIntent.getActivity(
                context, 100,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_title, open)
            return views
        }

        private fun bind(
            context: Context,
            views: RemoteViews,
            canWrite: Boolean,
            current: RotationMode?,
            mode: RotationMode,
            requestCode: Int,
            buttonId: Int,
            titleId: Int,
            subId: Int
        ) {
            val active = current == mode
            views.setInt(
                buttonId, "setBackgroundResource",
                if (active) R.drawable.widget_btn_active else R.drawable.widget_btn_idle
            )
            views.setTextColor(titleId, if (active) COLOR_ACTIVE_TEXT else COLOR_INACTIVE_TEXT)
            views.setTextColor(subId, if (active) COLOR_ACTIVE_SUB else COLOR_INACTIVE_SUB)

            val pending = if (canWrite) {
                val intent = Intent(context, RotationWidgetProvider::class.java).apply {
                    action = ACTION_SET_MODE
                    putExtra(EXTRA_MODE, mode.name)
                }
                PendingIntent.getBroadcast(
                    context, requestCode, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            } else {
                // Chưa cấp quyền: bấm nút sẽ mở app để cấp quyền
                PendingIntent.getActivity(
                    context, 100 + requestCode,
                    Intent(context, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            }
            views.setOnClickPendingIntent(buttonId, pending)
        }
    }
}
