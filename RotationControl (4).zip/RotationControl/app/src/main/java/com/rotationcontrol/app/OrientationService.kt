package com.rotationcontrol.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.ServiceCompat

/**
 * Giữ 1 cửa sổ overlay 1x1 trong suốt nằm trên cùng, có screenOrientation cố định.
 * Hệ thống lấy hướng của cửa sổ trên cùng nên hướng này đè lên cài đặt hệ thống
 * và cả yêu cầu xoay của các app (YouTube, trình phát video...).
 */
class OrientationService : Service() {

    companion object {
        @Volatile
        var running = false
        private const val CHANNEL_ID = "rotation_override"
        private const val NOTIFICATION_ID = 1
    }

    private lateinit var windowManager: WindowManager
    private var overlay: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notif_channel),
            NotificationManager.IMPORTANCE_LOW
        )
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val mode = RotationController.current(this)
        showNotification(mode)

        if (mode == RotationMode.AUTO || !RotationController.canOverlay(this)) {
            removeOverlay()
            running = false
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        applyOverlay(mode)
        running = true
        return START_STICKY
    }

    private fun showNotification(mode: RotationMode) {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = when (mode) {
            RotationMode.ROT_90 -> getString(R.string.notif_90)
            RotationMode.ROT_0 -> getString(R.string.notif_0)
            RotationMode.AUTO -> getString(R.string.notif_off)
        }
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_auto)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, notification,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
    }

    private fun applyOverlay(mode: RotationMode) {
        val orientation = if (mode == RotationMode.ROT_90) {
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }

        val existing = overlay
        val existingParams = params
        if (existing != null && existingParams != null) {
            existingParams.screenOrientation = orientation
            try {
                windowManager.updateViewLayout(existing, existingParams)
            } catch (e: Exception) {
                // bỏ qua
            }
            return
        }

        val lp = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.screenOrientation = orientation

        val view = View(this)
        try {
            windowManager.addView(view, lp)
            overlay = view
            params = lp
        } catch (e: Exception) {
            // thiếu quyền overlay hoặc hệ thống từ chối
        }
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // bỏ qua
            }
        }
        overlay = null
        params = null
    }

    override fun onDestroy() {
        removeOverlay()
        running = false
        super.onDestroy()
    }
}
