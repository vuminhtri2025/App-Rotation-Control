package com.rotationcontrol.app

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Ô bật/tắt 0°: Bật = luôn giữ hướng dọc, Tắt = theo cài đặt của máy. */
class Rotation0TileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()
        val isOn = RotationController.current(this) == RotationMode.ROT_0
        val target = if (isOn) RotationMode.AUTO else RotationMode.ROT_0
        // Chưa có quyền overlay (hoặc không bật được dịch vụ): mở app để xử lý
        if (!RotationController.apply(this, target)) openApp()
        updateTile()
    }

    private fun updateTile() {
        val tile = qsTile ?: return
        val isOn = RotationController.current(this) == RotationMode.ROT_0
        tile.label = getString(R.string.tile0_label)
        tile.icon = Icon.createWithResource(this, R.drawable.ic_portrait)
        tile.state = if (isOn) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= 29) {
            tile.subtitle = getString(if (isOn) R.string.tile_on else R.string.tile_off)
        }
        tile.updateTile()
    }

    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
            )
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}
