package com.rotationcontrol.app

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Ô trong bảng cài đặt nhanh: mỗi lần chạm đổi vòng Tắt → 90° → 0° → Tắt. */
class RotationTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()
        val next = when (RotationController.current(this)) {
            RotationMode.AUTO -> RotationMode.ROT_90
            RotationMode.ROT_90 -> RotationMode.ROT_0
            RotationMode.ROT_0 -> RotationMode.AUTO
        }
        // Chưa có quyền overlay (hoặc không bật được dịch vụ): mở app để xử lý
        if (!RotationController.apply(this, next)) openApp()
        updateTile()
    }

    private fun updateTile() {
        val tile = qsTile ?: return
        val mode = RotationController.current(this)
        val (iconRes, sub) = when (mode) {
            RotationMode.AUTO -> Pair(R.drawable.ic_auto, getString(R.string.opt_auto))
            RotationMode.ROT_90 -> Pair(R.drawable.ic_landscape, getString(R.string.opt_90))
            RotationMode.ROT_0 -> Pair(R.drawable.ic_portrait, getString(R.string.opt_0))
        }
        tile.label = getString(R.string.tile_label)
        tile.icon = Icon.createWithResource(this, iconRes)
        tile.state = if (mode == RotationMode.AUTO) Tile.STATE_INACTIVE else Tile.STATE_ACTIVE
        if (Build.VERSION.SDK_INT >= 29) tile.subtitle = sub
        tile.updateTile()
    }

    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
            )
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}
