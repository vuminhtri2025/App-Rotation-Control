package com.rotationcontrol.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews

class RotationWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, buildViews(context))
        }
    }

    companion object {
        private val COLOR_ACTIVE_TEXT = Color.parseColor("#FFFFFF")
        private val COLOR_INACTIVE_TEXT = Color.parseColor("#AEAEB2")

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, RotationWidgetProvider::class.java)
            )
            if (ids.isEmpty()) return
            val views = buildViews(context)
            for (id in ids) manager.updateAppWidget(id, views)
        }

        private fun buildViews(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_rotation)
            val canOverlay = RotationController.canOverlay(context)
            val current = RotationController.current(context)

            bind(context, views, canOverlay, current, RotationMode.AUTO, 0, R.id.btn_auto, R.id.txt_auto)
            bind(context, views, canOverlay, current, RotationMode.ROT_90, 1, R.id.btn_90, R.id.txt_90)
            bind(context, views, canOverlay, current, RotationMode.ROT_0, 2, R.id.btn_0, R.id.txt_0)
            return views
        }

        private fun bind(
            context: Context,
            views: RemoteViews,
            canOverlay: Boolean,
            current: RotationMode,
            mode: RotationMode,
            requestCode: Int,
            buttonId: Int,
            titleId: Int
        ) {
            val active = current == mode
            views.setInt(
                buttonId, "setBackgroundResource",
                if (active) R.drawable.widget_btn_active else R.drawable.widget_btn_idle
            )
            views.setTextColor(titleId, if (active) COLOR_ACTIVE_TEXT else COLOR_INACTIVE_TEXT)

            val pending = if (canOverlay || mode == RotationMode.AUTO) {
                val intent = Intent(context, SetModeReceiver::class.java).apply {
                    action = SetModeReceiver.ACTION_SET_MODE
                    putExtra(SetModeReceiver.EXTRA_MODE, mode.name)
                }
                PendingIntent.getBroadcast(
                    context, requestCode, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            } else {
                // Chưa cấp quyền: bấm nút sẽ mở app để cấp quyền
                PendingIntent.getActivity(
                    context, 100 + requestCode,
                    Intent(context, MainActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            }
            views.setOnClickPendingIntent(buttonId, pending)
        }
    }
}
