package com.rotationcontrol.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var cardAuto: View
    private lateinit var card90: View
    private lateinit var card0: View
    private lateinit var permissionBanner: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cardAuto = findViewById(R.id.card_auto)
        card90 = findViewById(R.id.card_90)
        card0 = findViewById(R.id.card_0)
        permissionBanner = findViewById(R.id.permission_banner)

        cardAuto.setOnClickListener { select(RotationMode.AUTO) }
        card90.setOnClickListener { select(RotationMode.ROT_90) }
        card0.setOnClickListener { select(RotationMode.ROT_0) }
        findViewById<View>(R.id.btn_grant).setOnClickListener { openOverlaySettings() }

        requestNotificationPermission()
    }

    override fun onResume() {
        super.onResume()
        RotationController.ensureRunning(this)
        refresh()
    }

    private fun select(mode: RotationMode) {
        if (!RotationController.apply(this, mode)) {
            Toast.makeText(this, R.string.need_permission, Toast.LENGTH_SHORT).show()
            openOverlaySettings()
            return
        }
        refresh()
    }

    private fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun refresh() {
        permissionBanner.visibility =
            if (RotationController.canOverlay(this)) View.GONE else View.VISIBLE

        val current = RotationController.current(this)
        cardAuto.isSelected = current == RotationMode.AUTO
        card90.isSelected = current == RotationMode.ROT_90
        card0.isSelected = current == RotationMode.ROT_0

        RotationWidgetProvider.updateAll(this)
    }
}
