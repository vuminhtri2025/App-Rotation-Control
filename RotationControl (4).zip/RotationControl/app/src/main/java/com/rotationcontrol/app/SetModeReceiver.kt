package com.rotationcontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Nhận cú bấm từ widget và đổi chế độ xoay. */
class SetModeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val mode = runCatching {
            RotationMode.valueOf(intent.getStringExtra(EXTRA_MODE) ?: "")
        }.getOrNull() ?: return
        RotationController.apply(context, mode)
    }

    companion object {
        const val ACTION_SET_MODE = "com.rotationcontrol.app.ACTION_SET_MODE"
        const val EXTRA_MODE = "mode"
    }
}
