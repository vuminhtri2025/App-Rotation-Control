package com.rotationcontrol.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Khôi phục chế độ đã chọn sau khi khởi động lại máy hoặc cập nhật app. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        RotationController.ensureRunning(context)
        RotationWidgetProvider.updateAll(context)
    }
}
