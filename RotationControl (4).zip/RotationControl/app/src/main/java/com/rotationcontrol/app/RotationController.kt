package com.rotationcontrol.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat

enum class RotationMode { AUTO, ROT_90, ROT_0 }

/**
 * AUTO   : app không can thiệp, điện thoại nghe theo cài đặt xoay của hệ thống.
 * ROT_90 : ép hướng ngang (xoay ngược chiều kim đồng hồ 90°), đè lên hệ thống và mọi app.
 * ROT_0  : ép hướng dọc, đè lên hệ thống và mọi app (kể cả video YouTube).
 */
object RotationController {
    private const val PREFS = "rotation_prefs"
    private const val KEY_MODE = "mode"

    fun canOverlay(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun current(context: Context): RotationMode {
        val name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_MODE, null)
        return runCatching { RotationMode.valueOf(name ?: "") }
            .getOrDefault(RotationMode.AUTO)
    }

    private fun save(context: Context, mode: RotationMode) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_MODE, mode.name).apply()
    }

    /** Trả về false nếu chưa có quyền hiển thị trên ứng dụng khác. */
    fun apply(context: Context, mode: RotationMode): Boolean {
        val app = context.applicationContext
        if (mode == RotationMode.AUTO) {
            save(app, mode)
            app.stopService(Intent(app, OrientationService::class.java))
            RotationWidgetProvider.updateAll(app)
            refreshTile(app)
            return true
        }
        if (!canOverlay(app)) return false
        save(app, mode)
        RotationWidgetProvider.updateAll(app)
        refreshTile(app)
        return try {
            ContextCompat.startForegroundService(app, Intent(app, OrientationService::class.java))
            true
        } catch (e: Exception) {
            // Hệ thống không cho bật dịch vụ từ nền: mở app sẽ tự bật lại (ensureRunning)
            false
        }
    }

    private fun refreshTile(app: Context) {
        val tiles = listOf(RotationTileService::class.java, Rotation0TileService::class.java)
        for (cls in tiles) {
            try {
                TileService.requestListeningState(app, ComponentName(app, cls))
            } catch (e: Exception) {
                // bỏ qua
            }
        }
    }

    /** Dựng lại overlay nếu service bị tắt (mở app, khởi động lại máy, cập nhật app). */
    fun ensureRunning(context: Context) {
        val app = context.applicationContext
        val mode = current(app)
        if (mode == RotationMode.AUTO) return
        if (!canOverlay(app)) {
            save(app, RotationMode.AUTO)
            return
        }
        if (!OrientationService.running) {
            ContextCompat.startForegroundService(app, Intent(app, OrientationService::class.java))
        }
    }
}
